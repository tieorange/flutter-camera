module Dotenv
  VERSION = "2.2.0".freeze
end
