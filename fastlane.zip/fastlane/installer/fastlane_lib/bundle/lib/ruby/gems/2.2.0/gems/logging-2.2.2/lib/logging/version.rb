module Logging
  VERSION = "2.2.2".freeze

  # Returns the version string for the library.
  def self.version
    VERSION
  end
end
