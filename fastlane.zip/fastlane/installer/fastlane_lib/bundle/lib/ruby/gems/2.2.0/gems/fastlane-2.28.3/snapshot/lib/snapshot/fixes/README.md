### Fixes

This directory contains all the files we don't actually want to have, but are necessary due to open radars, e.g.

- [rdar://23323159](https://openradar.appspot.com/radar?id=6127019184095232): Screenshots are broken when simulator is not scaled at 100%
