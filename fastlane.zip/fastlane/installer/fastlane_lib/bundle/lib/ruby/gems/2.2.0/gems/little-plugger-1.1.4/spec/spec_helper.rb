
require File.expand_path(
    File.join(File.dirname(__FILE__), %w[.. lib little-plugger]))

