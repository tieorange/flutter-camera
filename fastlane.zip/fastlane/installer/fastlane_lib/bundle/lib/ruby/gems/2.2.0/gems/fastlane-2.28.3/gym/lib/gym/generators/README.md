All the classes that generate commands we want to execute
